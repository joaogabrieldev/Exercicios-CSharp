﻿//ENTRADA
//AB,AC,BC: real

//PROCESSAMENTO
// Escreva("Informe o valor do Lado AB do triângulo: ") 
// Leia (AB)
// Escreva("Informe o valor do Lado AC do triângulo: ") 
// Leia (AC)
// Escreva("Informe o valor do Lado BC do triângulo: ") 
// Leia (BC)

//SAÍDA
// Se (ladoAB != ladoAC E ladoAB != ladoBC E ladoAC != ladoBC) então
//    Escreva ("Esse Triângulo é Escaleno")
// Senão ( (AB != ladoAC E ladoAB == ladoBC) OU (ladoAC != ladoBC E ladoAC == ladoAB) )

//Não Consegui dar Prosseguimento